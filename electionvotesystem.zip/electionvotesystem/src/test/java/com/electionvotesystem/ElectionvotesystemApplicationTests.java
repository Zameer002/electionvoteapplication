package com.electionvotesystem;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.electionvotesystem.controller.VotingController;
import com.electionvotesystem.entity.Candidate;
import com.electionvotesystem.repository.VotingRepository;
import com.electionvotesystem.service.VotingService;

@SpringBootTest
class ElectionvotesystemApplicationTests {

	   @Mock
	    private VotingService votingService;

	    @InjectMocks
	    private VotingController votingController;

	    @Mock
	    private VotingRepository votingRepository;

	    @Test
	    public void testSaveNewCandidate() {
	     
	        String candidateName = "Alice";
	        when(votingService.save(candidateName)).thenReturn(null);

	        
	        ResponseEntity<String> response = votingController.save(candidateName);

	        
	        assertEquals("Candidate entered successfully.", response.getBody());
	        assertEquals(HttpStatus.CREATED, response.getStatusCode());
	    }

	    @Test
	    public void testSaveExistingCandidate() {
	        
	        String existingCandidateName = "Bob";
	        when(votingService.save(existingCandidateName)).thenReturn(new Candidate(existingCandidateName, 0));

	      
	        ResponseEntity<String> response = votingController.save(existingCandidateName);

	        
	        assertEquals("Candidate with name " + existingCandidateName + " is already present, please provide different name ", response.getBody());
	        assertEquals(HttpStatus.NOT_ACCEPTABLE, response.getStatusCode());
	    }

	    @Test
	    public void testVoteCount() {
	        
	        String candidateName = "Alice";
	        when(votingService.findByName(candidateName)).thenReturn(1);

	        
	        ResponseEntity<String> response = votingController.voteCount(candidateName);

	        
	        assertEquals("Vote cast successfully. Current vote count: 1", response.getBody());
	        assertEquals(HttpStatus.OK, response.getStatusCode());
	    }


	    @Test
	    public void testVotesList() {
	        
	        String candidateName = "Alice";
	        when(votingService.findByName(candidateName)).thenReturn(1);

	        
	        ResponseEntity<String> response = votingController.voteCount(candidateName);

	        
	        assertEquals("Vote cast successfully. Current vote count: 1", response.getBody());
	        assertEquals(HttpStatus.OK, response.getStatusCode());
	    }

	    @Test
	    void testNamesAndVoteCounts() {
	        List<Candidate> expectedCandidates = Arrays.asList(
	                new Candidate("Alice", 5),
	                new Candidate("Bob", 8),
	                new Candidate("Charlie", 3)
	        );

	        when(votingService.findnamesAndVoteCounts()).thenReturn(expectedCandidates);

	        List<Candidate> result = votingController.namesAndVoteCounts();

	        assertEquals(expectedCandidates.size(), result.size());
	        assertEquals(expectedCandidates, result);
	    }

	    @Test
	    void testGetWinner() {
	        List<Candidate> candidates = Arrays.asList(
	                new Candidate("Alice", 5),
	                new Candidate("Bob", 8),
	                new Candidate("Charlie", 3)
	        );

	        when(votingService.findnamesAndVoteCounts()).thenReturn(candidates);

	        String result = votingController.getWinner();

	        assertEquals("Winner(s): Bob with 8 votes", result);
	    }

	   
}
