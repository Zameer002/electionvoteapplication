package com.electionvotesystem.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.electionvotesystem.entity.Candidate;
import com.electionvotesystem.service.VotingService;

@RequestMapping("/")
@RestController
public class VotingController {

	@Autowired
	private VotingService votingService;
	
	@PostMapping("/entercandidate")
	public ResponseEntity<String> save(@RequestParam String candidateName) {
		Candidate candidate = votingService.save(candidateName);
		  if(candidate==null) {
			  
	            return new ResponseEntity<>("Candidate entered successfully.", HttpStatus.CREATED);
	        } else {
	            return new ResponseEntity<>("Candidate with name " + candidateName + " is already present, please provide different name " , HttpStatus.NOT_ACCEPTABLE);
	        }
	}
	
	@PostMapping("/castvote")
	public ResponseEntity<String> voteCount(@RequestParam String candidateName) {
		int voteCount = votingService.findByName(candidateName);
		if (voteCount != -1) {
            return new ResponseEntity<>("Vote cast successfully. Current vote count: " + voteCount, HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Invalid candidate.", HttpStatus.BAD_REQUEST);
        }
	}
	
	@GetMapping("/countvote")
	public ResponseEntity<String> countVote(@RequestParam String candidateName) {
		int voteCount = votingService.findCountVote(candidateName);
		if (voteCount != -1) {
            return new ResponseEntity<>("Vote count for " + candidateName + ": " + voteCount, HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Invalid candidate.", HttpStatus.BAD_REQUEST);
        }
	}
	
	@GetMapping("/listvote")
	public List<Candidate> namesAndVoteCounts() {
		List<Candidate> voteCount = votingService.findnamesAndVoteCounts();

		return voteCount;
		
	}
	
	
	@GetMapping("/getwinner")
	public String getWinner() {
	    Iterable<Candidate> candidates = votingService.findnamesAndVoteCounts();

	    //candidate with the maximum votes
	    Candidate winner = candidates.iterator().next();
	    for (Candidate candidate : candidates) {
	        if (candidate.getVoteCount() > winner.getVoteCount()) {
	            winner = candidate;
	        }
	    }

	    // Checking candidates with equal vote share
	    List<Candidate> equalVoteCandidates = new ArrayList<>();
	    for (Candidate candidate : candidates) {
	        if (candidate.getVoteCount() == winner.getVoteCount() && !candidate.equals(winner)) {
	            equalVoteCandidates.add(candidate);
	        }
	    }

	   
	    StringBuilder result = new StringBuilder("Winner(s): " + winner.getName() + " with " + winner.getVoteCount() + " votes");

	    if (!equalVoteCandidates.isEmpty()) {
	        result.append(", Equal votes with: ");
	        for (Candidate equalVoteCandidate : equalVoteCandidates) {
	            result.append(equalVoteCandidate.getName()).append(", ");
	        }

	        result.append(" with ").append(winner.getVoteCount()).append(" votes");
	    }

	    return result.toString();
	}
}
