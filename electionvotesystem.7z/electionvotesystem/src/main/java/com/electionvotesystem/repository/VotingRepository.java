package com.electionvotesystem.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.electionvotesystem.entity.Candidate;

@Repository
public interface VotingRepository extends JpaRepository<Candidate, Integer>{

	

	Candidate findByName(String candidateName);

}
