package com.electionvotesystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.electionvotesystem.entity.Candidate;
import com.electionvotesystem.repository.VotingRepository;

@Service
public class VotingService {

	@Autowired
	private VotingRepository votingRepository;
	
	private static int nextId = 1;
	
	public Candidate save(String candidateName) {
		Candidate existingCandidate = votingRepository.findByName(candidateName);
		if(existingCandidate==null) {
			Candidate candidate = new Candidate();
			 candidate.setName(candidateName);
	         candidate.setVoteCount(0);
	         candidate.setId(getNextId());
	        votingRepository.save(candidate);
		}
		return existingCandidate;
		
	}

	private int getNextId() {
		return nextId++;
	}
	public int findByName(String candidateName) {
		Candidate candidate = votingRepository.findByName(candidateName);
		if(candidate!=null) {
			candidate.setVoteCount(candidate.getVoteCount()+1);
			 votingRepository.save(candidate);
			 return candidate.getVoteCount();
		}
		return -1;
	}

	public int findCountVote(String candidateName) {
		Candidate candidate = votingRepository.findByName(candidateName);
		if(candidate!=null) {
			return candidate.getVoteCount();
		}
		return -1;
		
	}

	public List<Candidate> findnamesAndVoteCounts() {
		return votingRepository.findAll();
	}

}
